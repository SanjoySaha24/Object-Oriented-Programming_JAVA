/**** Creating new Thread ****/

/*Methodology for creating new thread :

	1. We can implement the Runnable interface.
	2. We can extend the Thread class, itself.

*/

class NewThread extends Thread{
	//Thread t;
	NewThread(){
		//t = new Thread(this,"Demo Thread");
		super("Demo Thread");
		System.out.println("Child Thread : " + this);
		start();
		
	}
	public void run(){
		try{
		for(int i=5;i>0;i--){
			System.out.println("Child Thread : " + i);
			Thread.sleep(500);
		}
		}catch(InterruptedException e){
			System.out.println("Child Thread Interrupted");
		}
	}
}

class ThreadDemo{
	public static void main(String args[]){
		new NewThread();

		try{
			for(int i=5;i>0;i--){
				System.out.println("Main Thread : " + i);
				Thread.sleep(1000);
			}
		}catch(InterruptedException e){
			System.out.println("Main Thread Interrupted");
		}
	}
}



