/******* Thread Priority *******/
/* Thread Priority Variables : 1. MIN_PRIORITY=1
			       2. MAX_PRIORITY=10
			       3. NORM_PRIORITY=5
We will access these variables by Thread.MIN_PRIORITY,because these variables defined as
static final.

The priority handling methods : 1. final void setPriority(int level)
				2. final int getPriority()
*/

class Clicker implements Runnable{
	int click=0;
	Thread t;
	private volatile boolean running=true;

	public Clicker(int p){
		t = new Thread(this);
		t.setPriority(p);
	}

	public void run(){
		while(running){
			click++;
		}
	}

	public void stop(){
		running = false;
	}

	public void start(){
		t.start();
	}
}

class HighLowPri{
	public static void main(String args[]){
		Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
		Clicker hi = new Clicker(Thread.NORM_PRIORITY + 3);

		Clicker lo = new Clicker(Thread.NORM_PRIORITY - 3);

		lo.start();
		hi.start();

		try{
			Thread.sleep(10000);
		}catch(InterruptedException e){
			System.out.println("Main Thread Interrupted");
		}

		lo.stop();
		hi.stop();

		try{
			hi.t.join();
			lo.t.join();
		}catch(InterruptedException e){
			System.out.println("Interrupted again found");
		}

		System.out.println("Low Value:" + lo.click);
		System.out.println("High Value:" + hi.click);
	}
}
		
		