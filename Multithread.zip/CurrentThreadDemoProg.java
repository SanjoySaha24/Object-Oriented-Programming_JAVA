class CurrentThreadDemoProg{
	public static void main(String args[]){
		Thread t = Thread.currentThread();
		System.out.println("Current Thread : " + t);

		t.setName("My Thread");
		t.setPriority(7);

		System.out.println("After change : " + t);

		try{
			for(int n=1;n<=10;n++){
				System.out.println(n);
				Thread.sleep(3000);
			}
		}catch(InterruptedException e){
			System.out.println("Main Thread Interrupted");
		}
	}
}


/** static void sleep(long milliseconds) throws InterruptedException **/