/****** Interthread Communication ******/

/* Three methods : 1. final void wait() throws InterruptedException
		2. final void notify()
		3. final void notifyAll()

wait() : that tells calling thread to give up the monitor and go to sleep until,
	 some other thread enters the same monitor and calls notify().

notify() : it wakes up a thread that called wait() on the same object.

notifyAll() : it wakes up all the threads that called wait() on the same object.
*/
/**** Example : Producer/Consumer problem ****/

class Q{
	int n;
	
	synchronized int get(){
		System.out.println("Got : " + n);
		return n;
	}

	synchronized void put(int n){
		this.n = n;
		System.out.println("Put : " + n);
	}
}

class Producer implements Runnable{
	Q q;

	Producer(Q q){
		this.q = q;
		new Thread(this,"Producer").start();
	}
 
	public void run(){
		int i = 0;
		
		while(true){
			q.put(++i);
		}
	}
}

class Consumer implements Runnable{
	Q q;

	Consumer(Q q){
		this.q = q;
		new Thread(this,"Consumer").start();
	}
 
	public void run(){
		
		while(true){
			q.get();
		}
	}
}

class PC{
	public static void main(String args[])
	{
		Q q = new Q();

		new Producer(q);
		new Consumer(q);

		System.out.println("Press ctrl-c to stop");
	}
}

