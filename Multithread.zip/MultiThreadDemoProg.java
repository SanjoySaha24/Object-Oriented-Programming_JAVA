class NewThread implements Runnable{
	Thread t;
	String name;
	NewThread(String s){
		name = s;//name = "Three"
		t = new Thread(this,name);//Thread : "One";"Two","Three"
		System.out.println("NewThread : " + t);
		t.start(); //Ready Q:One; Ready Q: One,Two; Ready Q: One,Two,Three
	}
	public void run(){
		try{
			for(int i=5;i>0;i--){
				System.out.println(name + ":" + i);
				Thread.sleep(1000);
			}
		}catch(InterruptedException e){
			System.out.println(name + " interrupted");
		}
		System.out.println(name + " exiting");
	}
}

class MultiThreadDemoProg{
	public static void main(String args[]){
		new NewThread("One");
		new NewThread("Two");
		new NewThread("Three");

		try{
			Thread.sleep(10000);//Main goes to block state
		}catch(InterruptedException e){
			System.out.println("Main thread interrupted");
		}
		System.out.println("Main Thread Exiting");
	}
}
//-------------------Output
/*One : 5
Two : 5
Three : 5
One : 4
Two : 4
Three : 4
One : 3
Three : 3
Two : 3
Three : 2
One : 2
Two : 2*/